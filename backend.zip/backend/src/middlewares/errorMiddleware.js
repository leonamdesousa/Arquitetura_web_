// Captura rotas que não existem
const notFound = (req, res, next) => {
    const error = new Error(`Não encontrado - ${req.originalUrl}`);
    res.status(404);
    next(error);
};

// Captura erros globais do sistema
const errorHandler = (err, req, res, next) => {
    // Se o status ainda for 200, mudamos para 500 (Erro interno)
    const statusCode = res.statusCode === 200 ? 500 : res.statusCode;
    
    res.status(statusCode).json({
        message: err.message,
        // Em desenvolvimento, mostramos onde o erro ocorreu. Em produção, escondemos.
        stack: process.env.NODE_ENV === 'production' ? null : err.stack,
    });
};

module.exports = { notFound, errorHandler };