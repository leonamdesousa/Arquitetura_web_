const Manga = require('../models/Manga');

exports.criarManga = async (req, res) => {
    try {
        const { titulo, autor, genero, capitulos } = req.body;
        const manga = await Manga.create({
            titulo,
            autor,
            genero,
            capitulos,
            usuario: req.user._id 
        });
        res.status(201).json(manga);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
};

exports.listarMangas = async (req, res) => {
    try {
        const mangas = await Manga.find().populate('usuario', 'nome');
        res.json(mangas);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};