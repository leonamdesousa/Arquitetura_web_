const mongoose = require('mongoose');

// DEFINIÇÃO DO SUB-SCHEMA DE COMENTÁRIOS
const ComentarioSchema = new mongoose.Schema({
    texto: { 
        type: String, 
        required: true, 
        trim: true 
    },
    usuarioNome: { 
        type: String, 
        required: true 
    },
    dataCriacao: { 
        type: Date, 
        default: Date.now 
    }
});

const MangaSchema = new mongoose.Schema({
    titulo: { 
        type: String, 
        required: [true, 'O titulo e obrigatorio'], 
        trim: true 
    },
    autor: { 
        type: String, 
        required: [true, 'O autor e obrigatorio'],
        trim: true 
    },
    genero: { 
        type: String,
        trim: true,
        default: 'Geral'
    },
    capitulos: { 
        type: Number, 
        default: 0,
        min: [0, 'O numero de capitulos nao pode ser negativo'] 
    },
    // RELACIONAMENTO: Vincula o manga ao administrador
    usuario: { 
        type: mongoose.Schema.Types.ObjectId, 
        ref: 'User', 
        required: true 
    },
    // NOVO CAMPO: LISTA DE COMENTÁRIOS
    comentarios: [ComentarioSchema]
    
}, { 
    timestamps: true 
});

// INDEXACAO: Melhora a performance de buscas por titulo
MangaSchema.index({ titulo: 'text' });

module.exports = mongoose.model('Manga', MangaSchema);