const express = require('express');
const router = express.Router();
// Importa a lógica de registro e login do controller
const { register, login } = require('../controllers/authcontroller');

// Rota para criação de novos administradores
router.post('/register', register);

// Rota para autenticação e geração de token de acesso
router.post('/login', login);

module.exports = router;