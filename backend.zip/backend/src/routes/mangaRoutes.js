const express = require('express');
const router = express.Router();
const Manga = require('../models/Manga');
const { protect } = require('../middlewares/authMiddleware');

// --- ROTAS PÚBLICAS ---

// Listar todos os mangás
router.get('/', async (req, res) => {
    try {
        const mangas = await Manga.find().populate('usuario', 'nome');
        res.json(mangas);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// ADICIONAR UM COMENTÁRIO (PÚBLICA)
// Removido o middleware "protect" para que o usuário comum possa comentar
router.post('/:id/comentarios', async (req, res) => {
    try {
        const manga = await Manga.findById(req.params.id);
        if (!manga) return res.status(404).json({ message: "Mangá não encontrado" });

        const novoComentario = {
            texto: req.body.texto,
            // Se o usuário não enviar um nome, define como "Leitor Anônimo"
            usuarioNome: req.body.usuarioNome || "Leitor Anônimo" 
        };

        manga.comentarios.push(novoComentario);
        await manga.save();
        
        res.status(201).json(manga);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

// --- ROTAS PROTEGIDAS (Precisa de Token de Admin) ---

// Cadastrar mangá
router.post('/', protect, async (req, res) => {
    try {
        const { titulo, autor, genero, capitulos } = req.body;
        const novoManga = await Manga.create({
            titulo, autor, genero, capitulos,
            usuario: req.user._id 
        });
        res.status(201).json(novoManga);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

// Remover um comentário (PROTEGIDA - Somente Admin pode moderar)
router.delete('/:mangaId/comentarios/:comentId', protect, async (req, res) => {
    try {
        const manga = await Manga.findById(req.params.mangaId);
        if (!manga) return res.status(404).json({ message: "Mangá não encontrado" });

        // Remove o comentário específico
        manga.comentarios = manga.comentarios.filter(
            (c) => c._id.toString() !== req.params.comentId
        );

        await manga.save();
        res.json({ message: "Comentário removido pelo administrador!" });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Atualizar um mangá
router.put('/:id', protect, async (req, res) => {
    try {
        let manga = await Manga.findById(req.params.id);
        if (!manga) return res.status(404).json({ message: "Mangá não encontrado" });

        if (manga.usuario.toString() !== req.user._id.toString() && req.user.role !== 'Admin') {
            return res.status(401).json({ message: "Sem permissão para editar" });
        }

        manga = await Manga.findByIdAndUpdate(req.params.id, req.body, { new: true });
        res.json(manga);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

// Deletar um mangá
router.delete('/:id', protect, async (req, res) => {
    try {
        const manga = await Manga.findById(req.params.id);
        if (!manga) return res.status(404).json({ message: "Mangá não encontrado" });

        if (manga.usuario.toString() !== req.user._id.toString() && req.user.role !== 'Admin') {
            return res.status(401).json({ message: "Sem permissão para deletar" });
        }

        await manga.deleteOne();
        res.json({ message: "Mangá removido com sucesso!" });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

module.exports = router;