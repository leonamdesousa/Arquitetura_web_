const express = require('express');
const cors = require('cors');
const connectDB = require('./config/db');
require('dotenv').config();

// 1. IMPORTAÇÃO DOS MIDDLEWARES DE ERRO (Adicione esta linha!)
const { notFound, errorHandler } = require('./middlewares/errorMiddleware'); 

// Importação das Rotas
const authRoutes = require('./routes/authRoutes');
const mangaRoutes = require('./routes/mangaRoutes');

const app = express();

// Conecta ao Banco de Dados (MongoDB Atlas)
connectDB(); 

// Middlewares Globais
app.use(cors());
app.use(express.json()); 

// Definição das Rotas Principais
app.use('/api/auth', authRoutes);
app.use('/api/mangas', mangaRoutes); 

// 2. MIDDLEWARES DE ERRO (Agora o sistema vai reconhecer as funções)
app.use(notFound);
app.use(errorHandler);

// Rota de Boas-vindas
app.get('/', (req, res) => {
    res.json({ 
        message: "API de Mangás Online", 
        versao: "1.0.0",
        status: "🚀 Servidor funcionando perfeitamente!"
    });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`🚀 Servidor rodando em http://localhost:${PORT}`);
});