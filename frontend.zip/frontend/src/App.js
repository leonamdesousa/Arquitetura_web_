import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Home from './pages/Home'; 
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';

// Componente para proteger a Dashboard
const PrivateRoute = ({ children }) => {
  const isAuthenticated = localStorage.getItem('userInfo');
  // Se não estiver logado, manda para o login
  return isAuthenticated ? children : <Navigate to="/login" />;
};

function App() {
  return (
    <Router>
      <Routes>
        {/* ROTA PRINCIPAL: Catalogo Publico (Qualquer um acessa) */}
        <Route path="/" element={<Home />} />
        
        {/* ROTA DE LOGIN: Onde o admin entra no sistema */}
        <Route path="/login" element={<Login />} />
        
        {/* ROTA RESTRITA: Somente administradores logados acessam */}
        <Route 
          path="/dashboard" 
          element={
            <PrivateRoute>
              <Dashboard />
            </PrivateRoute>
          } 
        />

        {/* REDIRECIONAMENTO GLOBAL: Se digitar algo errado, volta para a Home */}
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </Router>
  );
}

export default App;