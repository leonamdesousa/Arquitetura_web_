import React, { useEffect, useState } from 'react';
import api from '../api';
import { useNavigate } from 'react-router-dom';
import '../App.css'; 

const Dashboard = () => {
    // --- ESTADOS ---
    const [mangas, setMangas] = useState([]); // Lista principal de conteúdo
    const [abaAtiva, setAbaAtiva] = useState('mangas'); // Controle de navegação interna
    const [novoManga, setNovoManga] = useState({ 
        titulo: '', autor: '', genero: '', capitulos: 0, imagemUrl: '' 
    });
    const [novoAdmin, setNovoAdmin] = useState({ nome: '', email: '', senha: '' });
    const [editandoId, setEditandoId] = useState(null); // Armazena ID para alternar entre POST e PUT
    const [comentarioTexto, setComentarioTexto] = useState({}); // Controla inputs de resposta por card
    const navigate = useNavigate();

    // Recupera dados do administrador logado
    const userInfo = JSON.parse(localStorage.getItem('userInfo'));

    // --- BUSCA DE DADOS ---
    const fetchMangas = async () => {
        try {
            const { data } = await api.get('/mangas');
            setMangas(data);
        } catch (error) {
            console.error("Erro ao carregar mangás", error);
            // Se o token expirar ou for inválido, desloga o usuário
            if (error.response?.status === 401) {
                localStorage.removeItem('userInfo');
                navigate('/');
            }
        }
    };

    useEffect(() => { fetchMangas(); }, [navigate]);

    // --- PERSISTÊNCIA (CREATE / UPDATE) ---
    const handleSaveManga = async (e) => {
        e.preventDefault();
        if (novoManga.capitulos < 0) {
            alert("O NUMERO DE CAPITULOS NAO PODE SER NEGATIVO");
            return;
        }
        try {
            if (editandoId) {
                // Modo Edição
                await api.put(`/mangas/${editandoId}`, novoManga);
                alert('REGISTRO ATUALIZADO COM SUCESSO');
            } else {
                // Modo Criação
                await api.post('/mangas', novoManga);
                alert('NOVO MANGA ADICIONADO AO CATALOGO');
            }
            limparFormulario();
            fetchMangas();
        } catch (error) { alert('ERRO AO PROCESSAR OPERACAO'); }
    };

    // --- GERENCIAMENTO DE ACESSO ---
    const handleRegisterAdmin = async (e) => {
        e.preventDefault();
        try {
            await api.post('/auth/register', novoAdmin);
            alert("NOVO ADMINISTRADOR CADASTRADO!");
            setNovoAdmin({ nome: '', email: '', senha: '' });
            setAbaAtiva('mangas');
        } catch (err) { alert("ERRO AO CADASTRAR ADMIN"); }
    };

    // --- MODERAÇÃO DE COMENTÁRIOS ---
    const handleAddComentario = async (mangaId) => {
        const texto = comentarioTexto[mangaId];
        if (!texto || texto.trim() === "") return;
        try {
            await api.post(`/mangas/${mangaId}/comentarios`, { texto });
            setComentarioTexto({ ...comentarioTexto, [mangaId]: '' });
            fetchMangas();
        } catch (err) { alert("ERRO AO ENVIAR COMENTÁRIO"); }
    };

    const handleDeleteComentario = async (mangaId, comentId) => {
        if (window.confirm("EXCLUIR ESTE COMENTÁRIO?")) {
            try {
                await api.delete(`/mangas/${mangaId}/comentarios/${comentId}`);
                fetchMangas();
            } catch (err) { alert("ERRO AO EXCLUIR COMENTÁRIO"); }
        }
    };

    // --- UTILITÁRIOS ---
    const handlePrepareEdit = (manga) => {
        setEditandoId(manga._id);
        setNovoManga({ ...manga });
        window.scrollTo({ top: 0, behavior: 'smooth' }); // Feedback visual de subida
    };

    const handleDelete = async (id) => {
        if (window.confirm("TEM CERTEZA QUE DESEJA REMOVER?")) {
            try { 
                await api.delete(`/id/${id}`); // Rota de exclusão por ID
                fetchMangas(); 
            } catch (error) { alert("ERRO AO EXCLUIR"); }
        }
    };

    const limparFormulario = () => {
        setNovoManga({ titulo: '', autor: '', genero: '', capitulos: 0, imagemUrl: '' });
        setEditandoId(null);
    };

    const handleLogout = () => {
        localStorage.removeItem('userInfo');
        navigate('/');
    };

    return (
        <div style={{ minHeight: '100vh', backgroundColor: 'var(--bg-dark)' }}>
            
            {/* CABEÇALHO ADMINISTRATIVO */}
            <header style={{ backgroundColor: '#000', padding: '15px 0', borderBottom: '3px solid var(--primary-blue)' }}>
                <div className="container" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '10px' }}>
                    <h1 className="logo" style={{ margin: 0, fontSize: '1.4rem' }}>DRAGON <span className="text-blue">ADMIN</span></h1>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '15px', flexWrap: 'wrap' }}>
                        <button onClick={() => setAbaAtiva('mangas')} className="btn-outline" style={{ borderColor: abaAtiva === 'mangas' ? 'var(--primary-blue)' : '#fff', color: '#fff', padding: '5px 10px', fontSize: '0.7rem' }}>MANGÁS</button>
                        <button onClick={() => setAbaAtiva('usuarios')} className="btn-outline" style={{ borderColor: abaAtiva === 'usuarios' ? 'var(--primary-blue)' : '#fff', color: '#fff', padding: '5px 10px', fontSize: '0.7rem' }}>USUÁRIOS</button>
                        <span style={{ fontSize: '0.7rem', color: '#fff' }}>SESSÃO: {userInfo?.nome}</span>
                        <button onClick={handleLogout} className="btn-blue" style={{ padding: '5px 15px', fontSize: '0.7rem' }}>SAIR</button>
                    </div>
                </div>
            </header>

            <div className="container" style={{ padding: '30px 15px' }}>
                
                {abaAtiva === 'usuarios' ? (
                    /* FORMULÁRIO DE CADASTRO DE ADMINS */
                    <section className="card" style={{ maxWidth: '500px', margin: '0 auto' }}>
                        <h3 className="section-title" style={{ textAlign: 'center' }}>CADASTRAR NOVO ADMINISTRADOR</h3>
                        <form onSubmit={handleRegisterAdmin}>
                            <div className="form-group">
                                <label>NOME COMPLETO</label>
                                <input className="input-control" type="text" value={novoAdmin.nome} onChange={e => setNovoAdmin({...novoAdmin, nome: e.target.value})} required />
                            </div>
                            <div className="form-group">
                                <label>E-MAIL</label>
                                <input className="input-control" type="email" value={novoAdmin.email} onChange={e => setNovoAdmin({...novoAdmin, email: e.target.value})} required />
                            </div>
                            <div className="form-group">
                                <label>SENHA</label>
                                <input className="input-control" type="password" value={novoAdmin.senha} onChange={e => setNovoAdmin({...novoAdmin, senha: e.target.value})} required />
                            </div>
                            <button type="submit" className="btn-blue" style={{ width: '100%' }}>CRIAR CONTA</button>
                        </form>
                    </section>
                ) : (
                    /* GERENCIAMENTO DE MANGÁS (CADASTRO E LISTAGEM) */
                    <>
                        <section className="card" style={{ marginBottom: '40px' }}>
                            <h3 className="section-title" style={{ color: 'var(--primary-blue)', fontSize: '1rem' }}>
                                {editandoId ? 'ATUALIZAR INFORMAÇÕES' : 'CADASTRAR NOVO MANGÁ'}
                            </h3>
                            <form onSubmit={handleSaveManga} className="grid-form">
                                <div className="form-group">
                                    <label>TITULO</label>
                                    <input className="input-control" type="text" value={novoManga.titulo} onChange={e => setNovoManga({...novoManga, titulo: e.target.value})} required />
                                </div>
                                <div className="form-group">
                                    <label>AUTOR</label>
                                    <input className="input-control" type="text" value={novoManga.autor} onChange={e => setNovoManga({...novoManga, autor: e.target.value})} required />
                                </div>
                                <div className="form-group">
                                    <label>GÊNERO</label>
                                    <input className="input-control" type="text" value={novoManga.genero} onChange={e => setNovoManga({...novoManga, genero: e.target.value})} />
                                </div>
                                <div className="form-group">
                                    <label>URL IMAGEM</label>
                                    <input className="input-control" type="text" value={novoManga.imagemUrl} onChange={e => setNovoManga({...novoManga, imagemUrl: e.target.value})} />
                                </div>
                                <div className="form-group">
                                    <label>CAPÍTULOS</label>
                                    <input className="input-control" type="number" value={novoManga.capitulos} onChange={e => setNovoManga({...novoManga, capitulos: parseInt(e.target.value) || 0})} />
                                </div>
                                <div className="form-actions" style={{ display: 'flex', gap: '10px' }}>
                                    <button type="submit" className="btn-blue flex-1" style={{ height: '45px' }}>SALVAR</button>
                                    {editandoId && <button type="button" onClick={limparFormulario} className="btn-outline flex-1" style={{ height: '45px', color: '#fff' }}>CANCELAR</button>}
                                </div>
                            </form>
                        </section>

                        <h2 className="section-title">TÍTULOS GERENCIADOS</h2>
                        
                        <div className="dashboard-grid">
                            {mangas.map((m) => (
                                <div key={m._id} className="card" style={{ display: 'flex', flexDirection: 'column' }}>
                                    <img src={m.imagemUrl} className="dash-card-img" alt="capa" />
                                    <div style={{ marginTop: '12px' }}>
                                        <span className="badge">{m.genero?.toUpperCase() || 'SEM GENERO'}</span>
                                        <h3 style={{ margin: '10px 0 5px 0', fontSize: '1rem' }}>{m.titulo.toUpperCase()}</h3>
                                        <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>AUTOR: {m.autor}</p>
                                        
                                        {/* ÁREA DE COMENTÁRIOS DO CARD */}
                                        <div style={{ marginTop: '15px', padding: '10px', backgroundColor: '#222', borderRadius: '8px' }}>
                                            <p style={{ fontSize: '0.65rem', fontWeight: 'bold', marginBottom: '8px', color: 'var(--primary-blue)' }}>COMENTÁRIOS</p>
                                            <div className="comments-container">
                                                {m.comentarios?.map(c => (
                                                    <div key={c._id} style={{ display: 'flex', justifyContent: 'space-between', backgroundColor: '#111', padding: '5px', borderRadius: '4px', marginBottom: '4px', fontSize: '0.65rem' }}>
                                                        <span><strong>{c.usuarioNome}:</strong> {c.texto}</span>
                                                        <button onClick={() => handleDeleteComentario(m._id, c._id)} style={{ color: 'var(--accent-red)', border: 'none', background: 'none', cursor: 'pointer' }}>✕</button>
                                                    </div>
                                                ))}
                                            </div>
                                            <div style={{ display: 'flex', gap: '5px' }}>
                                                <input className="input-mini" placeholder="Admin responde..." value={comentarioTexto[m._id] || ''} onChange={(e) => setComentarioTexto({...comentarioTexto, [m._id]: e.target.value})} />
                                                <button onClick={() => handleAddComentario(m._id)} className="btn-blue" style={{ height: '28px', padding: '0 8px', fontSize: '0.6rem' }}>OK</button>
                                            </div>
                                        </div>

                                        {/* AÇÕES DE EDIÇÃO/EXCLUSÃO */}
                                        <div style={{ display: 'flex', gap: '10px', marginTop: '15px', borderTop: '1px solid var(--border)', paddingTop: '10px' }}>
                                            <button onClick={() => handlePrepareEdit(m)} className="btn-blue flex-1" style={{ fontSize: '0.7rem', padding: '8px' }}>EDITAR</button>
                                            <button onClick={() => handleDelete(m._id)} className="btn-outline flex-1" style={{ fontSize: '0.7rem', color: 'var(--accent-red)', borderColor: 'var(--accent-red)' }}>EXCLUIR</button>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </>
                )}
            </div>
        </div>
    );
};

export default Dashboard;