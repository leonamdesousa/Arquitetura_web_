import React, { useEffect, useState } from 'react';
import api from '../api';
import { Link } from 'react-router-dom';
import '../App.css';

const Home = () => {
    // --- ESTADOS ---
    const [mangas, setMangas] = useState([]); // Armazena a lista vinda da API
    const [comentarioTexto, setComentarioTexto] = useState({}); // Texto do comentário por mangá
    const [comentarioNome, setComentarioNome] = useState({}); // Nome do autor por mangá

    // --- CARREGAMENTO DE DADOS ---
    const fetchPublicMangas = async () => {
        try {
            const { data } = await api.get('/mangas');
            setMangas(data);
        } catch (error) { console.error("Erro ao carregar"); }
    };

    // Busca os mangás assim que a página abre
    useEffect(() => { fetchPublicMangas(); }, []);

    // --- LÓGICA DE INTERAÇÃO ---
    const handleEnviarComentario = async (mangaId) => {
        const texto = comentarioTexto[mangaId];
        const nome = comentarioNome[mangaId] || "Leitor Anônimo"; // Default caso nome esteja vazio
        
        if (!texto) return alert("DIGITE UM COMENTARIO!");

        try {
            // Envia o comentário para a rota pública
            await api.post(`/mangas/${mangaId}/comentarios`, { texto, usuarioNome: nome });
            
            // Limpa os campos do mangá específico após enviar
            setComentarioTexto({ ...comentarioTexto, [mangaId]: '' });
            setComentarioNome({ ...comentarioNome, [mangaId]: '' });
            
            fetchPublicMangas(); // Atualiza a lista para exibir o novo comentário
        } catch (err) { alert("ERRO AO ENVIAR"); }
    };

    return (
        <div>
            {/* BARRA DE NAVEGAÇÃO PÚBLICA */}
            <header style={{ background: '#000', padding: '15px 0', borderBottom: '1px solid #222' }}>
                <div className="container" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <h1 style={{ fontSize: '1.4rem', margin: 0 }}>DRAGON <span style={{color: 'var(--primary-blue)'}}>CATÁLOGO</span></h1>
                    <Link to="/login" className="btn-blue" style={{ fontSize: '0.7rem', textDecoration: 'none' }}>ADMIN</Link>
                </div>
            </header>

            <div className="container" style={{ padding: '40px 0' }}>
                <h2 style={{ borderLeft: '4px solid var(--accent-red)', paddingLeft: '15px', marginBottom: '30px' }}>LANÇAMENTOS</h2>

                {/* GRID DE EXIBIÇÃO - Ajustado via CSS para ser responsivo */}
                <div className="manga-grid">
                    {mangas.map((m) => (
                        <div key={m._id} className="manga-card-home">
                            <div className="badge-red">HOT</div>
                            <img src={m.imagemUrl} alt={m.titulo} className="manga-poster" />
                            
                            <div style={{ padding: '15px' }}>
                                <h3 style={{ margin: '0 0 5px 0', fontSize: '1rem' }}>{m.titulo}</h3>
                                <p style={{ color: 'var(--text-muted)', fontSize: '0.8rem', marginBottom: '15px' }}>{m.autor}</p>

                                {/* FEEDBACK DE COMENTÁRIOS (Exibe apenas os 2 últimos) */}
                                <div style={{ background: '#222', padding: '10px', borderRadius: '8px' }}>
                                    <div style={{ maxHeight: '60px', overflowY: 'auto', fontSize: '0.7rem', marginBottom: '10px' }}>
                                        {m.comentarios?.slice(-2).map(c => (
                                            <div key={c._id} style={{ borderBottom: '1px solid #333', padding: '3px 0' }}>
                                                <b style={{color: 'var(--primary-blue)'}}>{c.usuarioNome}:</b> {c.texto}
                                            </div>
                                        ))}
                                    </div>

                                    {/* FORMULÁRIO RÁPIDO DE COMENTÁRIO */}
                                    <input 
                                        className="input-control" 
                                        style={{ padding: '5px', fontSize: '0.7rem', marginBottom: '5px' }}
                                        placeholder="Seu nome"
                                        value={comentarioNome[m._id] || ''}
                                        onChange={e => setComentarioNome({...comentarioNome, [m._id]: e.target.value})}
                                    />
                                    <div style={{ display: 'flex', gap: '5px' }}>
                                        <input 
                                            className="input-control" 
                                            style={{ padding: '5px', fontSize: '0.7rem' }}
                                            placeholder="Comentar..."
                                            value={comentarioTexto[m._id] || ''}
                                            onChange={e => setComentarioTexto({...comentarioTexto, [m._id]: e.target.value})}
                                        />
                                        <button onClick={() => handleEnviarComentario(m._id)} className="btn-blue" style={{ padding: '5px 10px', fontSize: '0.7rem' }}>OK</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default Home;