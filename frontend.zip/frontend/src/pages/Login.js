import React, { useState } from 'react';
import api from '../api';
import { useNavigate, Link } from 'react-router-dom';
import '../App.css';

const Login = () => {
    // --- ESTADOS ---
    const [email, setEmail] = useState('');
    const [senha, setSenha] = useState('');
    const navigate = useNavigate();

    // --- AUTENTICAÇÃO ---
    const handleLogin = async (e) => {
        e.preventDefault();
        try {
            // Envia credenciais para o backend
            const { data } = await api.post('/auth/login', { email, senha });
            
            // Persiste os dados do usuário e token no navegador
            localStorage.setItem('userInfo', JSON.stringify(data));
            
            // Redireciona para a área administrativa
            navigate('/dashboard');
        } catch (err) { 
            alert("ERRO: CREDENCIAIS INVALIDAS OU PROBLEMA NO SERVIDOR."); 
        }
    };

    return (
        /* Centraliza o formulário na tela usando o CSS global */
        <div className="auth-wrapper">
            <div className="card" style={{ width: '100%', maxWidth: '350px', textAlign: 'center' }}>
                
                <h2 className="logo" style={{ marginBottom: '30px' }}>
                    ACESSO <span style={{ color: 'var(--primary-blue)' }}>RESTRITO</span>
                </h2>
                
                <form onSubmit={handleLogin}>
                    <div className="form-group" style={{ textAlign: 'left' }}>
                        <label>E-MAIL CADASTRADO</label>
                        <input 
                            className="input-control" 
                            type="email" 
                            placeholder="exemplo@email.com"
                            onChange={e => setEmail(e.target.value)} 
                            required 
                        />
                    </div>
                    
                    <div className="form-group" style={{ textAlign: 'left' }}>
                        <label>SENHA DE ACESSO</label>
                        <input 
                            className="input-control" 
                            type="password" 
                            placeholder="••••••••"
                            onChange={e => setSenha(e.target.value)} 
                            required 
                        />
                    </div>
                    
                    <button className="btn-blue" style={{ width: '100%', marginTop: '10px' }} type="submit">
                        ENTRAR NO SISTEMA
                    </button>
                </form>

                {/* LINKS DE APOIO */}
                <div style={{ marginTop: '25px', fontSize: '0.8rem' }}>
                    <p style={{ color: 'var(--text-muted)', margin: 0 }}>
                        ÁREA EXCLUSIVA PARA ADMINISTRADORES
                    </p>
                    
                    <Link to="/" className="text-link" style={{ display: 'block', marginTop: '15px' }}>
                        ← VOLTAR AO CATÁLOGO
                    </Link>
                </div>
            </div>
        </div>
    );
};

export default Login;