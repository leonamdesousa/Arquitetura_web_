import React, { useState } from 'react';
import api from '../api';
import '../App.css';

const Register = () => {
    // --- ESTADO DO FORMULÁRIO ---
    const [form, setForm] = useState({ nome: '', email: '', senha: '' });

    // --- LÓGICA DE CADASTRO ---
    const handleRegister = async (e) => {
        e.preventDefault();
        try {
            // Envia os dados coletados para a rota de registro
            await api.post('/auth/register', form);
            alert("NOVO ADMINISTRADOR CADASTRADO COM SUCESSO!");
            
            // Reseta o formulário após o sucesso
            setForm({ nome: '', email: '', senha: '' }); 
        } catch (err) { 
            alert("ERRO AO REALIZAR CADASTRO. VERIFIQUE SE O E-MAIL JÁ EXISTE."); 
        }
    };

    return (
        /* Container centralizado usando as classes do App.css */
        <div className="card" style={{ maxWidth: '450px', margin: '20px auto' }}>
            <h2 className="logo" style={{ textAlign: 'center', marginBottom: '30px', fontSize: '1.2rem' }}>
                NOVO <span className="text-blue">ADMIN</span>
            </h2>
            
            <form onSubmit={handleRegister}>
                {/* CAMPOS DE ENTRADA DINÂMICOS */}
                <div className="form-group">
                    <label>NOME COMPLETO</label>
                    <input 
                        className="input-control" 
                        type="text" 
                        value={form.nome}
                        placeholder="NOME DO NOVO ADMIN"
                        onChange={e => setForm({...form, nome: e.target.value})} 
                        required 
                    />
                </div>
                
                <div className="form-group">
                    <label>E-MAIL</label>
                    <input 
                        className="input-control" 
                        type="email" 
                        value={form.email}
                        placeholder="EMAIL@SISTEMA.COM"
                        onChange={e => setForm({...form, email: e.target.value})} 
                        required 
                    />
                </div>
                
                <div className="form-group">
                    <label>SENHA</label>
                    <input 
                        className="input-control" 
                        type="password" 
                        value={form.senha}
                        placeholder="SENHA PROVISÓRIA"
                        onChange={e => setForm({...form, senha: e.target.value})} 
                        required 
                    />
                </div>
                
                {/* BOTÃO DE SUBMISSÃO PADRONIZADO */}
                <button className="btn-blue" style={{ width: '100%', marginTop: '10px' }} type="submit">
                    CADASTRAR USUÁRIO
                </button>
            </form>
        </div>
    );
};

export default Register;